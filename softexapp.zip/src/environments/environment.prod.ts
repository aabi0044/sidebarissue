export const environment = {
  production: true,
  fire:{
    apiKey: "AIzaSyCIn2xAfKc3QpW0UFYbiH4eL6I43eHYxkY",
    authDomain: "softex-app.firebaseapp.com",
    databaseURL: "https://softex-app.firebaseio.com",
    projectId: "softex-app",
    storageBucket: "softex-app.appspot.com",
    messagingSenderId: "986601769839",
    appId: "1:986601769839:web:e4c6b4d68990ce2408b69a"
  }
};
